from .detection import Detect


__all__ = ['Detect']
